﻿using Microsoft.AspNetCore.Mvc;

namespace ProvaWeb.Controllers
{
    public class UsuarioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
