﻿namespace ProvaWeb.Enums
{
    public enum PerfilEnum
    {
        Admin = 1,
        Padrao = 2
    }
}
